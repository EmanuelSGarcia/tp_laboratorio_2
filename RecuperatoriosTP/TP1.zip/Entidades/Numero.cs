﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {
        private double numero;

        /// <summary>
        /// Constructor que asgina numero en 0
        /// </summary>
        public Numero()
        {
            this.numero = 0;
        }

        /// <summary>
        /// Constructor con un numero establecido por parametros
        /// </summary>
        /// <param name="numero"></param>
        public Numero(double numero)
            :this(numero.ToString())
        {
        }

        /// <summary>
        /// Constructor con un numero establecido por parametros el cual convierte el numero en String a Double
        /// </summary>
        /// <param name="strNumero"></param>
        public Numero(string strNumero)
        {
            SetNumero = strNumero;
        }

        /// <summary>
        /// Establece el numero ya validado
        /// </summary>
        public string SetNumero
        {
            set
            {
                this.numero = Numero.ValidarNumero(value);
            }
        }

        /// <summary>
        /// Valida que sea un numero
        /// </summary>
        /// <param name="numero"></param>
        /// <returns>El numero validado, caso contrario 0</returns>
        private static double ValidarNumero(string numero)
        {
            if (double.TryParse(numero, out double numeroValidado))
                return numeroValidado;
            else
                return 0;
        }

        /// <summary>
        /// Realiza la operacion de resta entre dos numeros
        /// </summary>
        /// <param name="numero1"></param>
        /// <param name="numero2"></param>
        /// <returns>El resultado de la operacion,caso contrario double.NaN</returns>
        public static double operator -(Numero numero1, Numero numero2)
        {
            if (numero1 is null || numero2 is null)
                return double.NaN;
            else
                return numero1.numero - numero2.numero;
        }

        /// <summary>
        /// Realiza la operacion de multiplicacion entre dos numeros
        /// </summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns>El resultado de la operacion,caso contrario double.NaN</returns>
        public static double operator *(Numero n1, Numero n2)
        {
            if (n1 is null || n2 is null)
                return double.NaN;
            else
                return n1.numero * n2.numero;
        }

        /// <summary>
        /// Realiza la operacion de division entre dos numeros
        /// </summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns>El resultado de la operacion,caso contrario double.MinValue</returns>
        public static double operator /(Numero n1, Numero n2)
        {
            if (n1 is null || n2 is null || n2.numero is 0)
                return double.MinValue;
            else
                return n1.numero / n2.numero;
        }

        /// <summary>
        /// Realiza la operacion de suma entre dos numeros
        /// </summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns>El resultado de la operacion,caso contrario double.NaN</returns>
        public static double operator +(Numero n1, Numero n2)
        {
            if (n1 is null || n2 is null)
                return double.NaN;
            else
                return n1.numero + n2.numero;
        }

        /// <summary>
        /// Convierte un numero binario a decimal
        /// </summary>
        /// <param name="binario"></param>
        /// <returns>El numero parseado,caso contrario retorna una string de error</returns>
        public static string BinarioDecimal(string binario)
        {
            if (int.TryParse(binario, out int numeroValidado) && numeroValidado > 0)
            {
                return Convert.ToInt32(binario, 2).ToString();
            }
            else
                return "Valor inválido";

        }

        /// <summary>
        /// Convierte un numero decimal (double) a binario
        /// </summary>
        /// <param name="numero"></param>
        /// <returns>El numero parseado,caso contrario retorna una string de error</returns>
        public static string DecimalBinario(double numero)
        {
            return DecimalBinario(numero.ToString());
        }

        /// <summary>
        ///  Convierte un numero decimal (string) a binario
        /// </summary>
        /// <param name="numero"></param>
        /// <returns>El numero parseado,caso contrario retorna una string de error</returns>
        public static string DecimalBinario(string numero)
        {
            if(int.TryParse(numero,out int numeroValidado) && numeroValidado>0)
            {
                return Convert.ToString(numeroValidado, 2);
            }
            else
            {
                return "Valor inválido";
            }
        }
    }
}
