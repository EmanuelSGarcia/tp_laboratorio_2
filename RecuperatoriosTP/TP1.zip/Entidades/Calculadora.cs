﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Calculadora
    {
        /// <summary>
        /// Valida que sean operadores -,/,*,+
        /// </summary>
        /// <param name="operador">el operador a validar</param>
        /// <returns></returns>
        private static string ValidarOperador(string operador)
        {
            if (operador != "-" && operador != "/" && operador != "*")
                return "+";

            return operador;
        }

        /// <summary>
        /// Realiza la operacion matematica 
        /// </summary>
        /// <param name="num1"></param>
        /// <param name="num2"></param>
        /// <param name="operador">el operador a validar</param>
        /// <returns></returns>
        public double Operar(Numero num1, Numero num2, string operador)
        {
            double resultado = double.NaN;
            string opcion = ValidarOperador(operador);
            switch (opcion)
            {
                case "+":
                    resultado = num1 + num2;
                    break;
                case "-":
                    resultado = num1 - num2;
                    break;
                case "/":
                    resultado = num1 / num2;
                    break;
                case "*":
                    resultado = num1 * num2;
                    break;
            }
            return resultado;
        }
    }
}
