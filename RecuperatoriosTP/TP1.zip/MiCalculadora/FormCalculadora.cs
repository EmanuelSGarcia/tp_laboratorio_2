﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class FormCalculadora : Form
    {
        public FormCalculadora()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Cierra el formulario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// realiza la operacion matematica
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOperar_Click(object sender, EventArgs e)
        {
            lblResultado.Text = (FormCalculadora.Operar(txtNumero1.Text, txtNumero2.Text, cmbOperador.Text)).ToString();
        }


        /// <summary>
        /// Opera con los parametros asignados
        /// </summary>
        /// <param name="numero1"></param>
        /// <param name="numero2"></param>
        /// <param name="operador"></param>
        /// <returns>El resultado</returns>
        private static double Operar(string numero1, string numero2, string operador)
        {
            Calculadora calcu = FormCalculadora.LaCalculadora();
            Numero num1 = new Numero(numero1);
            Numero num2 = new Numero(numero2);
            return (calcu.Operar(num1, num2, operador));
        }

        /// <summary>
        /// Instancia una calculadora y la devuelve
        /// </summary>
        /// <returns>La calculadora</returns>
        public static Calculadora LaCalculadora()
        {
            return new Calculadora();
        }

        /// <summary>
        /// Limpia todos los campos del formulario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            foreach (var aux in this.Controls)
            {
                if (aux is TextBox)
                {
                    ((TextBox)aux).Clear();
                }
                else if (aux is ComboBox)
                {
                    ((ComboBox)aux).SelectedItem = null;
                }
                lblResultado.Text = "0";
            }
        }

        /// <summary>
        /// Convierte el numero resultante en binario
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnConvertirABinario_Click(object sender, EventArgs e)
        {
            lblResultado.Text = Numero.DecimalBinario(lblResultado.Text);
        }

        /// <summary>
        /// Convierte el numero resultante en decimal
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnConvertirADecimal_Click(object sender, EventArgs e)
        {
            lblResultado.Text = Numero.BinarioDecimal(lblResultado.Text);
        }
    }
}
