﻿using Excepciones;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Archivos
{
    public class Texto : IArchivo<string>
    {
        /// <summary>
        /// Crea y guarda datos en un archivo, en caso de existir agrega mas datos
        /// </summary>
        /// <param name="archivo"></param>
        /// <param name="datos"></param>
        /// <returns>true si pudo, false si no</returns>
        public bool Guardar(string archivo, string datos)
        {
            try
            {
                using (StreamWriter archivoTxt = new StreamWriter(archivo,true))
                {
                    archivoTxt.Write(datos);
                }
                return true;
            }
            catch (Exception exception)
            {
                throw new ArchivosException(exception);
            }
        }

        /// <summary>
        /// Lee los datos de un archivo y los almacena en la variable de referencia
        /// </summary>
        /// <param name="archivo"></param>
        /// <param name="datos"></param>
        /// <returns>true si pudo/false si no</returns>
        public bool Leer(string archivo, out string datos)
        {
            try
            {
                using (StreamReader archivoTxt = new StreamReader(archivo))
                {
                    datos = archivoTxt.ReadToEnd();
                }
                return true;
            }
            catch (Exception exception)
            {
                throw new ArchivosException(exception);
            }
        }
    }
}
