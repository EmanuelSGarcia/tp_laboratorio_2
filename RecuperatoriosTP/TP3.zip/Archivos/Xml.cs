﻿using Excepciones;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Archivos
{
    public class Xml<T> : IArchivo<T>
    {
        /// <summary>
        /// Guarda en un archivo los datos
        /// </summary>
        /// <param name="archivo"></param>
        /// <param name="datos"></param>
        /// <returns>true si pudo,false si no</returns>
        public bool Guardar(string archivo, T datos)
        {
            try
            {
                using (StreamWriter archivoXml = new StreamWriter(archivo))
                {
                    XmlSerializer serializador = new XmlSerializer(typeof(T));
                    serializador.Serialize(archivoXml, datos);
                }
                return true;
            }
            catch (Exception exception)
            {
                throw new ArchivosException(exception);
            }
        }

        /// <summary>
        /// lee los datos de un archivo xml y los almacena en la variable de referencia
        /// </summary>
        /// <param name="archivo"></param>
        /// <param name="datos"></param>
        /// <returns>true si pudo,false si no</returns>
        public bool Leer(string archivo, out T datos)
        {
            try
            {
                using (StreamReader archivoXml = new StreamReader(archivo))
                {
                    XmlSerializer serializador = new XmlSerializer(typeof(T));
                    datos = (T)serializador.Deserialize(archivoXml);
                }
                return true;
            }
            catch (Exception exception)
            {
                throw new ArchivosException(exception);
            }
        }
    }
}
