﻿using Clases_Abstractas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Clases_Instanciables.Universidad;

namespace Clases_Instanciables
{
    public sealed class Alumno : Universitario
    {
        public enum EEstadoCuenta
        {
            AlDia,
            Deudor,
            Becado
        }

        private EClases claseQueToma;
        private EEstadoCuenta estadoCuenta;

        /// <summary>
        /// genera un alumno vacio
        /// </summary>
        public Alumno()
        {
        }

        /// <summary>
        /// genera un alumno con los campos correspondiente y el estado de cuenta al dia
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        /// <param name="claseQueToma"></param>
        public Alumno(int id, string nombre, string apellido, int dni, ENacionalidad nacionalidad, EClases claseQueToma)
            : this(id,nombre,apellido,dni.ToString(),nacionalidad,claseQueToma,EEstadoCuenta.AlDia)
        {
        }

        /// <summary>
        /// genera un alumno con los campos correspondientes de alumno
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        /// <param name="claseQueToma"></param>
        /// <param name="estadoCuenta"></param>
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad,
            EClases claseQueToma,EEstadoCuenta estadoCuenta)
            : base(id, nombre, apellido, dni, nacionalidad)
        {
            this.estadoCuenta = estadoCuenta;
            this.claseQueToma = claseQueToma;
        }

        /// <summary>
        /// muestra los datos de un alumno
        /// </summary>
        /// <returns>string de datos</returns>
        protected override string MostrarDatos()
        {
            StringBuilder datos = new StringBuilder();
            string estadoCuenta = string.Empty;

            datos.AppendLine(base.MostrarDatos());
            switch(this.estadoCuenta)
            {
                case EEstadoCuenta.AlDia:
                    estadoCuenta = "Cuota al día";
                    break;
                case EEstadoCuenta.Becado:
                    estadoCuenta = "Alumno Becado";
                    break;
                case EEstadoCuenta.Deudor:
                    estadoCuenta = "Cuota/s en deuda";
                    break;
            }
            datos.AppendFormat("\nESTADO DE CUENTA: {0}\n", estadoCuenta);
            datos.AppendFormat(this.ParticiparEnClase());
            return datos.ToString();
        }

        /// <summary>
        /// muestra las clases que toma el alumno
        /// </summary>
        /// <returns>string de datos</returns>
        protected override string ParticiparEnClase()
        {
            StringBuilder datos = new StringBuilder();

            datos.AppendFormat("TOMA CLASE DE {0}", this.claseQueToma);

            return datos.ToString();
        }

        /// <summary>
        /// expone los datos de MostrarDatos de el alumno
        /// </summary>
        /// <returns>string de datos</returns>
        public override string ToString()
        {
            return this.MostrarDatos();
        }

        /// <summary>
        /// Verifica si el alumno toma la clase y si su estado de cuenta no es deudor
        /// </summary>
        /// <param name="alumno"></param>
        /// <param name="clase"></param>
        /// <returns>true si cumple los requisitos, false si no</returns>
        public static bool operator ==(Alumno alumno, EClases clase)
        {
            bool respuesta = false;

            if(!(alumno.Equals(null)))
            {
                if(alumno.claseQueToma.Equals(clase))
                    if(alumno.estadoCuenta != EEstadoCuenta.Deudor)
                        respuesta = true;
            }

            return respuesta;
        }

        /// <summary>
        /// Verifica si el alumno no toma la clase y si su estado de cuenta es deudor
        /// </summary>
        /// <param name="alumno"></param>
        /// <param name="clase"></param>
        /// <returns>true si cumple los requisitos,false si no</returns>
        public static bool operator !=(Alumno alumno, EClases clase)
        {
            bool respuesta = false;

            if(alumno.claseQueToma.Equals(clase))
                respuesta = true;

            return respuesta;
        }
    }
}
