﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Clases_Instanciables;
using EntidadesAbstractas;


namespace UnitTests
{
    [TestClass]
    public class TestValidaNulo
    {
        [TestMethod]
        public void TestNulo()
        {
            // Arrange 
            int legajo = 108544, dni = 39673087;
            string nombre = "Emanuel Sebastían", apellido = "Garcia";
            Persona.ENacionalidad nacionalidad = Persona.ENacionalidad.Argentino;
            Universidad.EClases claseQueToma = Universidad.EClases.Laboratorio;

            // Act
            Alumno alumno = new Alumno(legajo, nombre, apellido, dni, nacionalidad, claseQueToma);
            Profesor profesor = new Profesor(legajo, nombre, apellido, dni.ToString(), nacionalidad);
            Jornada jornada = new Jornada(claseQueToma, profesor);
            Universidad universidad = new Universidad();


            // Assert
            ComprobarAlumno_NoTieneCampoNulo(alumno);
            ComprobarProfesor_NoTieneCampoNulo(profesor);
            ComprobarJornada_NoTieneCampoNulo(jornada);
            ComprobarUniversidad_NoTieneCampoNulo(universidad);
        }
        private void ComprobarAlumno_NoTieneCampoNulo(Alumno alumno)
        {
            Assert.IsNotNull(alumno);
            Assert.IsNotNull(alumno.Nombre);
            Assert.IsNotNull(alumno.Apellido);
            Assert.IsNotNull(alumno.DNI);
            Assert.IsNotNull(alumno.Nacionalidad);
        }

        private void ComprobarProfesor_NoTieneCampoNulo(Profesor profesor)
        {
            Assert.IsNotNull(profesor);
            Assert.IsNotNull(profesor.Nombre);
            Assert.IsNotNull(profesor.Apellido);
            Assert.IsNotNull(profesor.DNI);
            Assert.IsNotNull(profesor.Nacionalidad);
        }

        private void ComprobarJornada_NoTieneCampoNulo(Jornada jornada)
        {
            Assert.IsNotNull(jornada);
            Assert.IsNotNull(jornada.Alumnos);
            Assert.IsNotNull(jornada.Clase);
            Assert.IsNotNull(jornada.Instructor);
        }

        private void ComprobarUniversidad_NoTieneCampoNulo(Universidad universidad)
        {
            Assert.IsNotNull(universidad);
            Assert.IsNotNull(universidad.Alumnos);
            Assert.IsNotNull(universidad.Jornada);
            Assert.IsNotNull(universidad.Profesores);
        }
    }
}
