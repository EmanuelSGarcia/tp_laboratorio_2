﻿using Excepciones;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace EntidadesAbstractas
{
    public abstract class Persona
    {
        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }

        private string nombre;
        private string apellido;
        private ENacionalidad nacionalidad;
        private int dni;

        public Persona()
        {
        }

        /// <summary>
        /// genera una persona con los atributos validados
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre,string apellido,ENacionalidad nacionalidad)
        {
            this.Nombre = nombre;
            this.Apellido = apellido;
            this.Nacionalidad = nacionalidad;
        }

        /// <summary>
        /// genera una persona con los atributos validados
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre,string apellido,int dni,ENacionalidad nacionalidad)
            :this(nombre,apellido,nacionalidad)
        {
            this.DNI = dni; 
        }

        /// <summary>
        /// genera una persona con los atributos validados
        /// </summary>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Persona(string nombre,string apellido,string dni,ENacionalidad nacionalidad)
            : this(nombre, apellido, nacionalidad)
        {
            this.StringToDNI = dni;
        }

        /// <summary>
        /// retorna el nombre de la persona o la asigna con su validacion correspondiente
        /// </summary>
        public string Nombre
        {
            get => this.nombre;
            set => this.nombre = Persona.ValidarNombreApellido(value);
        }

        /// <summary>
        /// retorna el apellido de la persona o lo asigna con su validacion correspondiente
        /// </summary>
        public string Apellido
        {
            get => this.apellido;
            set => this.apellido = Persona.ValidarNombreApellido(value);
        }

        /// <summary>
        /// retorna la nacionalidad de la persona o la asigna
        /// </summary>
        public ENacionalidad Nacionalidad
        {
            get => this.nacionalidad;
            set => this.nacionalidad = value;
        }

        /// <summary>
        /// retorna el dni de la persona o lo asigna con su validacion correspondiente
        /// </summary>
        public int DNI
        {
            get => this.dni;
            set => this.dni = Persona.ValidarDni(this.nacionalidad,value);
        }

        /// <summary>
        /// asigna el dni de la persona validado y parseado a int  
        /// </summary>
        public string StringToDNI
        {
            set => this.dni = Persona.ValidarDni(this.nacionalidad,value);
        }

        /// <summary>
        /// Valida que el DNI se encuentre en el rango correspondiente a su nacionalidad
        /// </summary>
        /// <param name="nacionalidad"></param>
        /// <param name="dato"></param>
        /// <returns>DNI</returns>
        private static int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            switch (nacionalidad)
            {
                case ENacionalidad.Argentino:
                    if (dato < 1 || dato > 89999999)
                        throw new NacionalidadInvalidaException();
                    break;
                case ENacionalidad.Extranjero:
                    if (dato < 90000000 || dato > 99999999)
                        throw new NacionalidadInvalidaException();
                    break;
            }

            return dato;
        }

        /// <summary>
        /// Valida que el DNI presente el formato correcto
        /// </summary>
        /// <param name="nacionalidad"></param>
        /// <param name="dato"></param>
        /// <returns>DNI validado</returns>
        private static int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            if (!(int.TryParse(dato, out int datoValidado)))
                throw new DniInvalidoException("El DNI debe ser solo numeros");
            else
            {
                if (dato.Length < 1 || dato.Length > 8)
                    throw new DniInvalidoException("El DNI debe tener entre 1 y 8 digitos numericos");
            }

            return Persona.ValidarDni(nacionalidad,datoValidado);
        }

        /// <summary>
        /// Valida que el nombre/apellido tenga el formato correcto
        /// </summary>
        /// <param name="dato"></param>
        /// <returns>dato validado de lo contrario vacio</returns>
        private static string ValidarNombreApellido(string dato)
        {
            Regex letrasValidas = new Regex(@"^[a-zA-ZñÑáéíóúÁÉÍÓÚüÜ ]+$");
            string retorno = string.Empty;
            if (letrasValidas.IsMatch(dato))
                retorno = dato;

            return dato;
        }

        /// <summary>
        /// Retorna apellido/s y nombre/s concatenados, y la nacionalidad de la persona 
        /// </summary>
        /// <returns>apellido/s,nombre/s y nacionalidad</returns>
        public override string ToString()
        {
            StringBuilder datos = new StringBuilder();

            datos.AppendFormat("NOMBRE COMPLETO: {0}, {1}\n", this.apellido, this.nombre);
            datos.AppendFormat("NACIONALIDAD: {0}\n\n", this.nacionalidad);

            return datos.ToString();
        }
    }
}
