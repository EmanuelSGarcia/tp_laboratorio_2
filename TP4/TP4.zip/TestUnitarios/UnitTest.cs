﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace TestUnitarios
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void PruebaInstanciaDeListaPaquetes()
        {
            //Arrange + Act
            Correo correoPrueba = new Correo();
            //Assert
            Assert.IsNotNull(correoPrueba.Paquetes);
        }

        [TestMethod]
        public void PruebaDosPaquetesIguales()
        {
            //Arrange
            Correo correoPrueba = new Correo();
            Paquete PaquetePrueba1 = new Paquete("De la peña 1900", "0123456789");
            Paquete PaquetePrueba2 = new Paquete("Bartolomé Mitre 750", "0123456789");

            //act
            correoPrueba = correoPrueba + PaquetePrueba1;

            try
            {
                correoPrueba = correoPrueba + PaquetePrueba2;
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is TrackingIdRepetidoException);
            }
        }
    }
}
