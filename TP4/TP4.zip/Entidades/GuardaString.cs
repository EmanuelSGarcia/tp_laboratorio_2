﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class GuardaString
    {
        /// <summary>
        /// Guarda un archivo de texto en el escritorio de la maquina, en caso de no existir creara uno, de lo contrario agregara información en él
        /// </summary>
        /// <param name="texto"></param>
        /// <param name="archivo"></param>
        /// <returns>true si pudo, una exception si no</returns>
        public static bool Guardar(this string texto, string archivo)
        {
            bool sobrescribir = true;
            try
            {
                if (File.Exists(archivo))
                    sobrescribir = false;

                using (StreamWriter archivoTexto = new StreamWriter(Environment.GetFolderPath(Environment.SpecialFolder.Desktop)+"\\" +archivo, sobrescribir))
                {
                    archivoTexto.WriteLine(texto);
                }
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}