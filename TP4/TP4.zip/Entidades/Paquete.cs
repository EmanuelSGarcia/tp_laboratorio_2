﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Paquete : IMostrar<Paquete>
    {
        public delegate void DelegadoEstado(Object sender, EventArgs eventArgs);

        public enum EEstado
        {
            Ingresado = 0,
            EnViaje = 1,
            Entregado = 2
        }

        private string direccionEntrega;
        private EEstado estado;
        private string trackingID;
        public event DelegadoEstado InformarEstado;

        /// <summary>
        /// Genera una paquete con su dirección de entrega y tracking ID
        /// </summary>
        /// <param name="direccionEntrega"></param>
        /// <param name="trackingID"></param>
        public Paquete(string direccionEntrega, string trackingID)
        {
            this.direccionEntrega = direccionEntrega;
            this.trackingID = trackingID;
        }

        public string DireccionEntrega
        {
            get => direccionEntrega;
            set => direccionEntrega = value;
        }

        public EEstado Estado
        {
            get => estado;
            set => estado = value;
        }

        public string TrackingID
        {
            get => trackingID;
            set => trackingID = value;
        }

        /// <summary>
        /// Cambia a su siguiente estado al paquete con un delay de 4 segundos,informando su estado atravez de el evento InformarEstado.
        /// Al llegar a su ultimo estado guarda el paquete en la BD 
        /// </summary>
        public void MockCicloDeVida()
        {
            try
            {
                this.InformarEstado.Invoke(this, null);
                while (this.estado != EEstado.Entregado)
                {
                    System.Threading.Thread.Sleep(4000);

                    if (this.estado == EEstado.Ingresado)
                        this.estado = EEstado.EnViaje;
                    else if (this.estado == EEstado.EnViaje)
                        this.estado = EEstado.Entregado;

                    this.InformarEstado.Invoke(this, null);
                }
                PaqueteDAO.Insertar(this);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Dos paquetes son iguales si el TrakingID es igual.
        /// </summary>
        /// <param name="paquete1"></param>
        /// <param name="paquete2"></param>
        /// <returns></returns>
        public static bool operator ==(Paquete paquete1, Paquete paquete2)
        {
            bool respuesta = false;

            if (!(paquete1 is null || paquete2 is null))
            {
                if (paquete1.trackingID == paquete2.trackingID)
                    respuesta = true;
            }

            return respuesta;
        }

        public static bool operator !=(Paquete paquete1, Paquete paquete2)
        {
            return !(paquete1 == paquete2);
        }

        /// <summary>
        /// Devuelve la informacion del paquete
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return this.MostrarDatos(this);
        }

        /// <summary>
        /// Devuelve un string con el tracking id y la direccion de entrega del paquete
        /// </summary>
        /// <param name="elemento"></param>
        /// <returns></returns>
        public string MostrarDatos(IMostrar<Paquete> elemento)
        {
            string datos = string.Empty;
            if (elemento is Paquete)
            {
                Paquete p = (Paquete)elemento;

                datos = string.Format("{0} para {1}", p.trackingID, p.direccionEntrega);
            }
            return datos;
        }
    }
}
