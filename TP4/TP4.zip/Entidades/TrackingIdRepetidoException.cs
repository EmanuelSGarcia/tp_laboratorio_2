﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class TrackingIdRepetidoException : Exception
    {
        /// <summary>
        /// Genera una exception con un mensaje
        /// </summary>
        public TrackingIdRepetidoException(string mensaje)
            :base(mensaje)
        {
        }

        /// <summary>
        /// genera una exception con un mensaje y una innerexception
        /// </summary>
        /// <param name="mensaje"></param>
        /// <param name="inner"></param>
        public TrackingIdRepetidoException(string mensaje,Exception inner)
            :base(mensaje,inner)
        {
        }
    }
}
