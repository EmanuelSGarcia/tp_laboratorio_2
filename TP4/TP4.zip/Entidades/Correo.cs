﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{
    public class Correo : IMostrar<List<Paquete>>
    {

        private List<Thread> mockPaquetes;
        private List<Paquete> paquetes;

        /// <summary>
        /// Instancia las listas de mockPaquetes y paquetes
        /// </summary>
        public Correo()
        {
            this.mockPaquetes = new List<Thread>();
            this.paquetes = new List<Paquete>();
        }

        public List<Paquete> Paquetes
        {
            get => paquetes;
            set => paquetes = value;
        }

        /// <summary>
        /// Finaliza todos los hilos que se encuentran en ejecución
        /// </summary>
        public void FinEntregas()
        {
            foreach (Thread hiloEnLista in this.mockPaquetes)
            {
                if (hiloEnLista.IsAlive)
                {
                    hiloEnLista.Abort();
                }
            }
        }

        /// <summary>
        /// Agrega un paquete nuevo a la lista de un correo, crea un nuevo hilo con el ciclo de vida del paquete,lo añade a la lista de hilos de el correo y lo ejecuta.
        /// </summary>
        /// <param name="correo"></param>
        /// <param name="paquete"></param>
        /// <returns>El correo resultante</returns>
        public static Correo operator +(Correo correo, Paquete paquete)
        {
            if (!(correo is null || paquete is null))
            {
                foreach (Paquete paqueteEnLista in correo.paquetes)
                {
                    if (paqueteEnLista == paquete)
                        throw new TrackingIdRepetidoException("El paquete ya se encuentra en la lista");
                }

                correo.paquetes.Add(paquete);
                Thread hiloNuevo = new Thread(paquete.MockCicloDeVida);
                correo.mockPaquetes.Add(hiloNuevo);
                hiloNuevo.Start();
            }

            return correo;
        }

        /// <summary>
        /// Muesta los datos de los paquetes en la lista
        /// </summary>
        /// <param name="elemento"></param>
        /// <returns></returns>
        public string MostrarDatos(IMostrar<List<Paquete>> elemento)
        {
            string datos = string.Empty;

            if (elemento is Correo)
            {
                foreach (Paquete p in ((Correo)elemento).paquetes)
                {
                    datos += string.Format("{0} para {1} ({2})\n", p.TrackingID, p.DireccionEntrega, p.Estado.ToString());
                }
            }
            return datos;
        }
    }
}
