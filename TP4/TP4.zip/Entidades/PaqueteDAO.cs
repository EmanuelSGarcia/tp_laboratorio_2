﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class PaqueteDAO
    {
        public delegate void DelegadoErrorDB(string mensaje);

        private static SqlCommand comando;
        private static SqlConnection conexion;
        public static event DelegadoErrorDB errorGuardarDB;

        /// <summary>
        /// Intancia la cadena de conexión 
        /// </summary>
        static PaqueteDAO()
        {
            PaqueteDAO.conexion = new SqlConnection("Data Source=localhost;Initial Catalog=correo-sp-2017;Integrated Security=True");
        }

        /// <summary>
        /// Establece conexion con la DB, genera una query y asigna los datos de un paquete pasado por parametros
        /// </summary>
        /// <param name="p"></param>
        /// <returns>True si se pudo,una exception si no</returns>
        public static bool Insertar(Paquete p)
        {
            try
            {
                StringBuilder query = new StringBuilder();
                query.AppendFormat("INSERT INTO dbo.Paquetes(DireccionEntrega,trackingID,alumno) VALUES('{0}','{1}','{2}')", p.DireccionEntrega, p.TrackingID, "Emanuel García");

                PaqueteDAO.conexion.Open();
                comando = new SqlCommand(query.ToString(), conexion);
                comando.ExecuteNonQuery();
                return true;
            }
            catch (SqlException sqlEx)
            {
                StringBuilder datos = new StringBuilder();
                datos.AppendLine("Error al guardar la informacion en la base de datos:");
                datos.AppendLine(sqlEx.Message);
                errorGuardarDB.Invoke(datos.ToString());
                
                return false;
            }
            finally
            {
                PaqueteDAO.conexion.Close();
            }
        }
    }
}
