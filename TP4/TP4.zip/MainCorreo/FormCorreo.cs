﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MainCorreo
{
    public partial class FormCorreo : Form
    {
        private Correo correo;

        public FormCorreo()
        {
            InitializeComponent();
            this.correo = new Correo();
            PaqueteDAO.errorGuardarDB += paq_ErrorGuardarDB;
        }

        /// <summary>
        /// Crea un paquete nuevo,asocia su evento InformarEstado en el metodo paq_informaEstado, lo agrega a la lista de correo.
        /// Actualiza los estados de los paquetes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Paquete paqueteNuevo = new Paquete(txtDireccion.Text, mtxtTrackingID.Text);

            paqueteNuevo.InformarEstado += paq_InformaEstado;
            try
            {
                this.correo = this.correo + paqueteNuevo;
            }
            catch (TrackingIdRepetidoException exception)
            {
                MessageBox.Show(exception.Message, "Error al agregar nuevo paquete", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            this.ActualizarEstados();
        }

        /// <summary>
        /// Invoca a un delegado si se lo requiere o actualiza los estados de los paquetes 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void paq_InformaEstado(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado);
                this.Invoke(d, new object[] { sender, e });
            }
            else
            {
                this.ActualizarEstados();
            }
        }

        /// <summary>
        /// Actualiza los estados de los paquetes existentes en los ListBox
        /// </summary>
        private void ActualizarEstados()
        {
            lstEstadoIngresado.Items.Clear();
            lstEstadoEnViaje.Items.Clear();
            lstEstadoEntregado.Items.Clear();

            foreach (Paquete paqueteEnLista in this.correo.Paquetes)
            {
                switch (paqueteEnLista.Estado)
                {
                    case Paquete.EEstado.Ingresado:
                        lstEstadoIngresado.Items.Add(paqueteEnLista);
                        break;

                    case Paquete.EEstado.EnViaje:
                        lstEstadoEnViaje.Items.Add(paqueteEnLista);
                        break;

                    case Paquete.EEstado.Entregado:
                        lstEstadoEntregado.Items.Add(paqueteEnLista);
                        break;
                }
            }
        }

        /// <summary>
        /// Al cerrar el formulario se finalizaran todos los hilos en ejecución
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormCorreo_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.correo.FinEntregas();
        }

        /// <summary>
        /// Muestra la informacion de todos los paquetes en la lista.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMostrarTodos_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)correo);
        }

        /// <summary>
        /// Muestra la informacion del paquete selecionado en la ListBox de entregados
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mostrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<Paquete>((IMostrar<Paquete>)lstEstadoEntregado.SelectedItem);
        }

        /// <summary>
        /// Muestra la informacion de el elemento en caso de ser tipo correo o paquete, luego lo guarda en "salida.txt" en el escritorio de la maquina.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="elemento"></param>
        private void MostrarInformacion<T>(IMostrar<T> elemento)
        {
            if (!(elemento is null))
            {
                if (elemento is Correo || elemento is Paquete)
                {
                    string datos = elemento.MostrarDatos(elemento);
                    rtbMostrar.Text = datos;
                    try
                    {
                        GuardaString.Guardar(datos, "salida.txt");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error al guardar archivo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        /// <summary>
        /// Invoca a un delegado si se lo requiere o lanza un error al guardar en base de datos. 
        /// </summary>
        /// <param name="m"></param>
        private void paq_ErrorGuardarDB(string m)
        {
            if (this.InvokeRequired)
            {
                PaqueteDAO.DelegadoErrorDB d = new PaqueteDAO.DelegadoErrorDB(paq_ErrorGuardarDB);
                this.Invoke(d, new object[] { m });
            }
            else
            {
                MessageBox.Show(m, "Error al guardar en la base de datos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
