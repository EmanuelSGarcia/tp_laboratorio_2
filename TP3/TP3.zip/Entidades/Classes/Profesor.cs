﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Entidades.Alumno;
using static Entidades.Universidad;
using static EntidadesAbstractas.Persona;

namespace Entidades
{
    public sealed class Profesor : Universitario
    {
        private Queue<EClases> clasesDelDia;
        private static Random random;

        /// <summary>
        /// instancia el numero random
        /// </summary>
        static Profesor()
        {
            Profesor.random = new Random();
        }

        /// <summary>
        /// genera un profesor vacio
        /// </summary>
        public Profesor()
        {                   
        }
        
        /// <summary>
        /// genera un profesor con sus campos correspondientes,instancia la cola de clases del dia y asigna 2 clases a la misma
        /// </summary>
        /// <param name="id"></param>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Profesor(int id,string nombre,string apellido,string dni,ENacionalidad nacionalidad)
            :base(id,nombre,apellido,dni,nacionalidad)
        {
            this.clasesDelDia = new Queue<EClases>();
            this._randomClases(); 
        }

        /// <summary>
        /// Asigna 2 clases a la cola de clases de el profesor
        /// </summary>
        private void _randomClases()
        {
            int opcion, cantidadClases = 0;

            while (cantidadClases < 2)
            {
                opcion = Profesor.random.Next(1,5);

                System.Threading.Thread.Sleep(100);

                switch (opcion)
                {
                    case 1:
                        this.clasesDelDia.Enqueue(EClases.Laboratorio);
                        break;
                    case 2:
                        this.clasesDelDia.Enqueue(EClases.Programacion);
                        break;
                    case 3:
                        this.clasesDelDia.Enqueue(EClases.Legislacion);
                        break;
                    case 4:
                        this.clasesDelDia.Enqueue(EClases.SPD);
                        break;
                }
                ++cantidadClases;
            }
        }

        /// <summary>
        /// Muestra los datos de un profesor
        /// </summary>
        /// <returns>string de datos del profesor</returns>
        protected override string MostrarDatos()
        {
            StringBuilder datos = new StringBuilder();

            datos.AppendLine(base.MostrarDatos());
            datos.Append(this.ParticiparEnClase());

            return datos.ToString();
        }

        /// <summary>
        /// Muestra las clases del dia que tiene un profesor
        /// </summary>
        /// <returns>string de datos</returns>
        protected override string ParticiparEnClase()
        {
            StringBuilder datos = new StringBuilder();

            datos.AppendLine("CLASES DEL DIA:");
            if (!(this.clasesDelDia is null))
            {
                foreach (EClases clase in this.clasesDelDia)
                {
                    datos.AppendLine(clase.ToString());
                }
            }
            else
            {
                datos.Append("Ninguna");
            }

            return datos.ToString();
        }

        /// <summary>
        /// expone los datos de MostrarDatos el profesor
        /// </summary>
        /// <returns>string de datos</returns>
        public override string ToString()
        {
            StringBuilder datos = new StringBuilder();

            datos.AppendLine(this.MostrarDatos());

            return datos.ToString();
        }

        /// <summary>
        /// Verifica si un profesor tiene una clase en su lista de clases.
        /// </summary>
        /// <param name="profesor"></param>
        /// <param name="clase"></param>
        /// <returns>true si la tiene, false si no</returns>
        public static bool operator ==(Profesor profesor,EClases clase)
        {
            bool respuesta = false;

            foreach(EClases claseEnLista in profesor.clasesDelDia)
            {
                if (claseEnLista == clase)
                    respuesta = true;
            }

            return respuesta;
        }

        /// <summary>
        /// Verifica si un profesor no tiene una clase en su lista de clases
        /// </summary>
        /// <param name="profesor"></param>
        /// <param name="clase"></param>
        /// <returns>true si no la tiene, false si la tiene</returns>
        public static bool operator !=(Profesor profesor, EClases clase)
        {
            return !(profesor == clase);
        }
    }
}
