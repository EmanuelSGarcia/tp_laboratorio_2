﻿using EntidadesAbstractas;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Universitario :Persona
    {
        private int legajo;

        /// <summary>
        /// genera un universitario vacio
        /// </summary>
        public Universitario()
        {
        }

        /// <summary>
        /// genera un universitario con sus campos
        /// </summary>
        /// <param name="legajo"></param>
        /// <param name="nombre"></param>
        /// <param name="apellido"></param>
        /// <param name="dni"></param>
        /// <param name="nacionalidad"></param>
        public Universitario(int legajo,string nombre,string apellido,string dni,ENacionalidad nacionalidad)
            :base(nombre,apellido,dni,nacionalidad)
        {
            this.legajo = legajo;
        }

        /// <summary>
        /// muesta los datos de un universitario 
        /// </summary>
        /// <returns>string de datos</returns>
        protected virtual string MostrarDatos()
        {
            StringBuilder datos = new StringBuilder();

            datos.Append(base.ToString());
            datos.AppendFormat("LEGAJO NÚMERO: {0}", this.legajo);

            return datos.ToString();
        }

        protected abstract string ParticiparEnClase();

        /// <summary>
        /// comprueba si el objeto es de tipo Universitario
        /// </summary>
        /// <param name="objeto"></param>
        /// <returns></returns>
        public override bool Equals(object objeto)
        {
            bool respuesta = false;

            if (objeto is Universitario)
                respuesta = true;

            return respuesta;
        }

        /// <summary>
        /// verifica si un universitario es igual a otro por su tipo y luego por su DNI o legajo
        /// </summary>
        /// <param name="universitario1"></param>
        /// <param name="universitario2"></param>
        /// <returns>true si son iguales,false si no</returns>
        public static bool operator ==(Universitario universitario1,Universitario universitario2)
        {
            bool respuesta = false;

            if(universitario1.Equals(universitario2))
            {
                if(universitario1.DNI == universitario2.DNI || universitario1.legajo == universitario2.legajo)
                {
                    respuesta = true;
                }
            }

            return respuesta;
        }
        /// <summary>
        /// verifica si un universitario no es igual a otro por su tipo y luego por su DNI o legajo
        /// </summary>
        /// <param name="universitario1"></param>
        /// <param name="universitario2"></param>
        /// <returns>true si no son iguales,false si lo son</returns>
        public static bool operator !=(Universitario universitario1, Universitario universitario2)
        {
            return !(universitario1 == universitario2);
        }
    }
}
