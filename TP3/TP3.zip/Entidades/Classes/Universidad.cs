﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades
{
    public class Universidad
    {
        [Serializable]
        public enum EClases
        {
            Programacion,
            Laboratorio,
            Legislacion,
            SPD
        }

        private List<Alumno> alumnos;
        private List<Profesor> profesores;
        private List<Jornada> jornada;

        /// <summary>
        /// Instancia las listas de alumnos,profesores y jornadas
        /// </summary>
        public Universidad()
        {
            this.alumnos = new List<Alumno>();
            this.profesores = new List<Profesor>();
            this.jornada = new List<Jornada>();
        }

        /// <summary>
        /// retorna la lista de alumnos o asigna una
        /// </summary>
        public List<Alumno> Alumnos
        {
            get => alumnos;
            set => alumnos = value;
        }

        /// <summary>
        /// retorna la lista de profesores o asigna una
        /// </summary>
        public List<Profesor> Profesores
        {
            get => profesores;
            set => profesores = value;
        }

        /// <summary>
        /// retorna la lista de jornadas o asigna una
        /// </summary>
        public List<Jornada> Jornada
        {
            get => jornada;
            set => jornada = value;
        }

        /// <summary>
        /// retorna una jornada que se encuentre en el indice de I o asigna una
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        public Jornada this[int i]
        {
            get
            {
                return this.jornada[i];
            }
            set
            {
                this.jornada.Insert(i, value);
            }
        }

        /// <summary>
        /// Verifica si un alumno ya se encuentra en la lista de alumnos de una universidad
        /// </summary>
        /// <param name="universidad"></param>
        /// <param name="alumno"></param>
        /// <returns>true si esta, false si no se encuentra</returns>
        public static bool operator ==(Universidad universidad, Alumno alumno)
        {
            bool respuesta = false;

            foreach(Alumno alumnoEnLista in universidad.alumnos)
            {
                if(alumno == alumnoEnLista)
                {
                    respuesta = true;
                }
            }

            return respuesta;
        }

        /// <summary>
        /// Verifica si un alumno no se encuentra en la lista de alumnos de una universidad
        /// </summary>
        /// <param name="universidad"></param>
        /// <param name="alumno"></param>
        /// <returns>true si no esta, false si se encuentra</returns>
        public static bool operator !=(Universidad universidad, Alumno alumno)
        {
            return !(universidad == alumno);
        }

        /// <summary>
        /// Verifica si un profesor ya se encuentra en la lista de profesores de una universidad
        /// </summary>
        /// <param name="universidad"></param>
        /// <param name="profesor"></param>
        /// <returns>true si esta, false si no se encuentra</returns>
        public static bool operator ==(Universidad universidad, Profesor profesor)
        {
            bool respuesta = false;

            foreach(Profesor profesorEnLista in universidad.profesores)
            {
                if(profesorEnLista == profesor)
                {
                    respuesta = true;
                    break;
                }
            }
            return respuesta;
        }

        /// <summary>
        /// Verifica si un profesor no se encuentra en la lista de profesores de una universidad
        /// </summary>
        /// <param name="universidad"></param>
        /// <param name="profesor"></param>
        /// <returns>true si no esta, false si se encuentra</returns>
        public static bool operator !=(Universidad universidad, Profesor profesor)
        {
            return !(universidad == profesor);
        }

        /// <summary>
        /// Asigna una jornada a una universidad, con un profesor valido para dar la clase y alumnos disponibles para la misma
        /// </summary>
        /// <param name="universidad"></param>
        /// <param name="clase"></param>
        /// <returns>la universidad con la jornada en lista</returns>
        public static Universidad operator +(Universidad universidad, EClases clase)
        {
            Profesor profesorHabilitado = (universidad == clase);
            Jornada nuevaJornada = new Jornada(clase, profesorHabilitado); ;

            if (nuevaJornada is null)
                throw new SinProfesorException();
            else
            {
                foreach (Alumno alumnoHabilitado in universidad.alumnos)
                {
                    if (alumnoHabilitado == clase)
                    {
                        nuevaJornada.Alumnos.Add(alumnoHabilitado);
                    }
                }
            }
            universidad.jornada.Add(nuevaJornada);

            return universidad;
        }

        /// <summary>
        /// Asigna un alumno a la lista de alumnos de una universidad
        /// </summary>
        /// <param name="universidad"></param>
        /// <param name="alumno"></param>
        /// <returns>la universidad con el alumno en lista</returns>
        public static Universidad operator +(Universidad universidad, Alumno alumno)
        {
            if (universidad != alumno)
                universidad.alumnos.Add(alumno);
            else if (universidad == alumno)
                throw new AlumnoRepetidoException();

            return universidad;
        }

        /// <summary>
        /// Asigna un profesor a la lista de profesores de una universidad
        /// </summary>
        /// <param name="universidad"></param>
        /// <param name="profesor"></param>
        /// <returns>la universidad con el profesor en lista</returns>
        public static Universidad operator +(Universidad universidad, Profesor profesor)
        {
            if (universidad != profesor)
            {
                universidad.profesores.Add(profesor);
            }

            return universidad;
        }

        /// <summary>
        /// Busca el primer profesor que pueda dar clases en esta materia
        /// </summary>
        /// <param name="universidad"></param>
        /// <param name="clase"></param>
        /// <returns>el profesor buscado</returns>
        public static Profesor operator ==(Universidad universidad, EClases clase)
        {
            Profesor profesorBuscado = null;
            foreach (Profesor profesorEnLista in universidad.profesores)
            {
                if (profesorEnLista == clase)
                {
                    profesorBuscado = profesorEnLista;
                    break;
                }
            }

            if (profesorBuscado is null)
            {
                throw new SinProfesorException();
            }

            return profesorBuscado;
        }

        /// <summary>
        /// Busca el ultimo profesor que pueda dar clases en la materia
        /// </summary>
        /// <param name="universidad"></param>
        /// <param name="clase"></param>
        /// <returns></returns>
        public static Profesor operator !=(Universidad universidad, EClases clase)
        {
            Profesor profesorBuscado = null;
            foreach (Profesor profesorEnLista in universidad.profesores)
            {
                if (profesorEnLista != clase)
                {
                    profesorBuscado = profesorEnLista;
                    break;
                }
            }

            if (profesorBuscado is null)
            {
                throw new SinProfesorException();
            }

            return profesorBuscado;
        }

        /// <summary>
        /// Muesta los datos de la/s jornada/s en la lista de una universidad
        /// </summary>
        /// <param name="universidad"></param>
        /// <returns>string de datos de jornada/s</returns>
        private static string MostrarDatos(Universidad universidad)
        {
            StringBuilder datos = new StringBuilder();

            foreach (Jornada jornadaEnLista in universidad.jornada)
            {
                datos.Append(jornadaEnLista.ToString());
            }

            return datos.ToString();
        }

        /// <summary>
        /// expone los datos de MostrarDatos(Universidad)
        /// </summary>
        /// <returns>string de datos de jornada/s</returns>
        public override string ToString()
        {
            return Universidad.MostrarDatos(this);
        }

        /// <summary>
        /// Guarda los datos un de una universidad en formato .xml
        /// </summary>
        /// <param name="universidad"></param>
        /// <returns></returns>
        public static bool Guardar(Universidad universidad)
        {
            Xml<Universidad> archivoXml = new Xml<Universidad>();

            if(archivoXml.Guardar("Universidad.xml",universidad))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Lee los datos de la universidad en formato .xml
        /// </summary>
        /// <returns></returns>
        public static Universidad Leer()
        {
            Universidad nuevaUniversidad = null;
            Xml<Universidad> archivoXml = new Xml<Universidad>();

            archivoXml.Leer("Universidad.xml", out nuevaUniversidad);

            return nuevaUniversidad;
        }
    }
}
