﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Entidades.Universidad;

namespace Entidades
{
    public class Jornada
    {
        private List<Alumno> alumnos;
        private EClases clase;
        private Profesor instructor;

        /// <summary>
        /// instancia la lista de alumnos
        /// </summary>
        private Jornada()
        {
            this.alumnos = new List<Alumno>();
        }

        /// <summary>
        /// genera una jornada clase e instructor
        /// </summary>
        /// <param name="clase"></param>
        /// <param name="instructor"></param>
        public Jornada(EClases clase, Profesor instructor)
            : this()
        {
            this.clase = clase;
            this.instructor = instructor;
        }

        /// <summary>
        /// retorna una lista de alumnos en la jornada o la asigna
        /// </summary>
        public List<Alumno> Alumnos
        {
            get => alumnos;
            set => alumnos = value;
        }

        /// <summary>
        /// retorna la clase de la jornada o la asigna
        /// </summary>
        public EClases Clase
        {
            get => clase;
            set => clase = value;
        }

        /// <summary>
        /// retorna el profesor de la jornada o lo asigna
        /// </summary>
        public Profesor Instructor
        {
            get => instructor;
            set => instructor = value;
        }

        /// <summary>
        /// Verifica si un alumno ya se encuentra en la jornada
        /// </summary>
        /// <param name="jornada"></param>
        /// <param name="alumno"></param>
        /// <returns>boolean</returns>
        public static bool operator ==(Jornada jornada, Alumno alumno)
        {
            bool respuesta = false;

            foreach(Alumno alumnoEnLista in jornada.alumnos)
            {
                if(alumnoEnLista == alumno)
                {
                    respuesta = true;
                    break;
                }
            }

            return respuesta;
        }

        /// <summary>
        /// Verifica si un alumno no se encuentra en la jornada
        /// </summary>
        /// <param name="jornada"></param>
        /// <param name="alumno"></param>
        /// <returns>boolean</returns>
        public static bool operator !=(Jornada jornada, Alumno alumno)
        {
            return !(jornada == alumno);
        }

        /// <summary>
        /// Agrega un alumno a la jornada verificando que este no se encuentre previamente en la misma 
        /// </summary>
        /// <param name="jornada"></param>
        /// <param name="alumno"></param>
        /// <returns>la jornada con el alumno o sin él</returns>
        public static Jornada operator +(Jornada jornada, Alumno alumno)
        {
            if (jornada != alumno)
            {
                jornada.alumnos.Add(alumno);
            }

            return jornada;
        }

        /// <summary>
        /// Retorna un datos de la jornada con su tipo de clase,con profesor a cargo, y una lista de alumnos
        /// </summary>
        /// <returns>string de datos</returns>
        public override string ToString()
        {
            StringBuilder datos = new StringBuilder();

            datos.AppendLine("JORNADA:");
            datos.AppendFormat("CLASE DE {0} POR {1}", this.clase.ToString(), this.instructor);

            datos.AppendLine("ALUMNOS:");
            if (this.alumnos.Count > 0)
            {
                foreach (Alumno alumno in this.alumnos)
                {
                    datos.AppendLine(alumno.ToString());
                }
            }
            else
            {
                datos.AppendLine("Ninguno");
            }
            datos.Append("<--------------------------------------->\n\n");

            return datos.ToString();
        }

        /// <summary>
        /// guarda los datos de una jornada en formato .txt
        /// </summary>
        /// <param name="jornada"></param>
        /// <returns>si se pudo o no</returns>
        public static bool Guardar(Jornada jornada)
        {
            StringBuilder datos = new StringBuilder();
            Texto archivoTxt = new Texto();

            datos.Append(jornada.instructor);
            datos.AppendLine("CLASE DE " + jornada.clase);
            datos.AppendLine("\nALUMNOS:");
            foreach (Alumno alumnoEnLista in jornada.Alumnos)
            {
                datos.AppendLine(alumnoEnLista.ToString());
            }

            if (archivoTxt.Guardar("Jornada.txt", datos.ToString()))
                return true;

            return false;
        }

        /// <summary>
        /// carga los datos de una jornada en formato .txt
        /// </summary>
        /// <returns>string con datos de la jornada</returns>
        public static string Leer()
        {
            string textoEnArchivo = string.Empty;
            Texto archivoTxt = new Texto();

            archivoTxt.Leer("Jornada.txt", out textoEnArchivo);
            
            return textoEnArchivo;        
        }
    }
}
