﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Texto : IArchivo<string>
    {
        /// <summary>
        /// Guarda en un archivo los datos
        /// </summary>
        /// <param name="archivo"></param>
        /// <param name="datos"></param>
        /// <returns>true si pudo, false si no</returns>
        public bool Guardar(string archivo, string datos)
        {
            try
            {
                using (StreamWriter archivoTxt = new StreamWriter(archivo))
                {
                    archivoTxt.Write(datos);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Lee los datos de un archivo y los almacena en la variable de referencia
        /// </summary>
        /// <param name="archivo"></param>
        /// <param name="datos"></param>
        /// <returns>true si pudo/false si no</returns>
        public bool Leer(string archivo, out string datos)
        {
            using (StreamReader archivoTxt = new StreamReader(archivo))
            {
                datos = archivoTxt.ReadToEnd();
            }
            return true;
        }
    }
}
