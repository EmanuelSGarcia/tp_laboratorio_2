﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DniInvalidoException : Exception
    {
        private static string mensajeBase = "DNI invalido";

        public DniInvalidoException()
            :base(mensajeBase)
        {
        }

        public DniInvalidoException(Exception exception)
            : base(mensajeBase,exception)
        {
        }

        public DniInvalidoException(string mensaje)
            :base(mensaje)
        {
        }

        public DniInvalidoException(string mensaje, Exception exception)
            : base(mensaje,exception)
        {
        }

    }
}
