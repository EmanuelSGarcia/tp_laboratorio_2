﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace UnitTests
{
    [TestClass]
    public class TestExcepciones
    {
        [TestMethod]
        public void TestExcepciones_PrimerCaso()
        {
            try
            {
                // Arrange 
                Alumno alumno;
                //Act
                alumno = CrearAlumno_NacionalidadInvalidaException();
                // Assert
                Assert.Fail("No se tiro la excepcion de NacionalidadInvalidadException");
            }
            catch(Exception excepcion)
            {
                // Assert
                Assert.IsTrue(excepcion is NacionalidadInvalidaException);
            }
        }

        [TestMethod]
        public void TestExcepciones_SegundCaso()
        {
            try
            {
                // Arrange 
                Alumno alumno;
                //Act
                alumno = CrearAlumno_DniInvalidoException();
                // Assert
                Assert.Fail("No se tiro la excepcion de DniInvalidoException");
            }
            catch (Exception excepcion)
            {
                // Assert
                Assert.IsTrue(excepcion is DniInvalidoException);
            }
        }

        private static Alumno CrearAlumno_NacionalidadInvalidaException()
        {
            return new Alumno(1, "Juan", "Lopez", "12234456",
            EntidadesAbstractas.Persona.ENacionalidad.Extranjero, Universidad.EClases.Programacion,
            Alumno.EEstadoCuenta.Becado);
        }

        private static Alumno CrearAlumno_DniInvalidoException()
        {
            return new Alumno(1, "Juan", "Lopez", "1223445z",
            EntidadesAbstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Programacion,
            Alumno.EEstadoCuenta.Becado);
        }
    }
}
