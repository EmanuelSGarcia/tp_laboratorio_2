﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;
using EntidadesAbstractas;


namespace UnitTests
{
    [TestClass]
    public class TestValidaNumero
    {
        [TestMethod]
        public void TestValidaDNI()
        {
            // Arrange 
            int legajo = 108544, dni = 39673087;
            string nombre = "Emanuel", apellido = "Garcia";
            Persona.ENacionalidad nacionalidad = Persona.ENacionalidad.Argentino;
            Universidad.EClases claseQueToma = Universidad.EClases.Laboratorio;
            Alumno.EEstadoCuenta estadoCuenta = Alumno.EEstadoCuenta.AlDia;

            // Act
            Alumno alumno = new Alumno(legajo, nombre, apellido, dni.ToString(), nacionalidad, claseQueToma,estadoCuenta);

            // Assert
            Assert.AreEqual(alumno.DNI, dni);
        }
    }
}
